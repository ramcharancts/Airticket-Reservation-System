﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLL;
using DEL;
public partial class Register : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       

        RangeValidator1.MaximumValue = DateTime.Now.Date.ToString("MM/dd/yyyy");
        RangeValidator1.MinimumValue = DateTime.Now.Date.AddYears(-130).ToString("MM/dd/yyyy");

    }
    protected void txtName_TextChanged(object sender, EventArgs e)
    {
        txtName.MaxLength = 50;
    }
    protected void txtUserName_TextChanged(object sender, EventArgs e)
    {

    }
    
    protected void txtSSNNumber_TextChanged(object sender, EventArgs e)
    {

    }
    protected void ddlSSNType_SelectedIndexChanged(object sender, EventArgs e)
    {
       
        switch (ddlSSNType.SelectedItem.Text)
        {
            case "Aadhar": revSSNNumber.ValidationExpression = "([0-9]{12})";
                revSSNNumber.ErrorMessage = "Enter Valid Number";
                            txtSSNNumber.MaxLength = 12;
                break;
            case "Driving Licence": revSSNNumber.ValidationExpression = "(^[A-Z]{2}[0-9]{14}$)";
                revSSNNumber.ErrorMessage = "Enter Valid Number";
                             txtSSNNumber.MaxLength = 15;
                break;

            case "PAN": revSSNNumber.ValidationExpression = "([A-Z]{5}[0-9]{4}[A-Z]{1})";
                revSSNNumber.ErrorMessage = "Enter Valid Number";
                txtSSNNumber.MaxLength = 10;
                break;
        }
    }

    user_master u = new user_master();
    user_masterBLL um = new user_masterBLL();
    user_master use = new user_master();
    protected void btnSave_Click(object sender, EventArgs e)
    {
      
        u.customer_name = txtName.Text;
        u.date_of_birth = txtDOB.Text;
        u.email_id = txtEmail.Text.ToLower();
        u.phone_number = txtPhoneNumber.Text;
        u.password = txtPassword.Text;
        u.address = txtAddress.Text;
        if (RadioBtnFemale.Checked)
        {
            u.gender = "Female";
        }
        if (RadioBtnMale.Checked)
        {
            u.gender = "Male";
        }
        if (RadioBtnOther.Checked)
        {
            u.gender = "Other";
        }
        u.ssn_type = ddlSSNType.SelectedValue;
        u.ssn_number = txtSSNNumber.Text;

        if (um.email(txtEmail.Text.ToLower()))
        {
            Label1.Text = "Email already exists";
        }
        else if (um.SSN(txtSSNNumber.Text))
        {
            Label1.Text = "SSN Number already exists";
        }
        else
        {

            if (um.insertusermaster(u))
            {

                Label1.Text = "Success";
                Response.Redirect("Home.aspx");
            }

            else
            {
                Label1.Text = "Registration Failed";
            }
            //use = um.getID(u);
        }
    }

  
    protected void RadioBtnMale_CheckedChanged(object sender, EventArgs e)
    {

    }
}