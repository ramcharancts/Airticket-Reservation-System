﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAL;
using DEL;
using BLL;
public partial class Cancel : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
          if (Session["userid"] == null)
           {
            Response.Redirect("Home.aspx");
           }
          if (!Page.IsPostBack)
          {
              GVCancel.Visible = true;
          }
    }
    protected void GVCancel_SelectedIndexChanged(object sender, EventArgs e)
    {
        booking_masterBLL bmbll = new booking_masterBLL();
       

        booking_master bm = bmbll.selectBooking(GVCancel.SelectedRow.Cells[0].Text);
        string flightid = bm.flight_id;
        int seats =Convert.ToInt32( bm.no_of_seats);

        int totalSeats = bmbll.SelectTotalSeats(flightid);
        int updatedSeats = totalSeats + Convert.ToInt32(seats);
        bmbll.UpdateTotalNoOfSeats(flightid, updatedSeats);

        if (bmbll.deletebooking_master(GVCancel.SelectedRow.Cells[0].Text))
        {
            lblStatus.Text = "Booking Cancelled";
            GVCancel.DataBind();
        }
       
    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Search.aspx");
    }
}