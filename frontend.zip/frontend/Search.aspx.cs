﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLL;
using DAL;
using DEL;
public partial class Search : System.Web.UI.Page
{
    search_temp_masterDAL sda = new search_temp_masterDAL();
    search_temp_masterBLL sbll = new search_temp_masterBLL();
    protected void Page_Load(object sender, EventArgs e)
    {
       
        if (Session["userid"] == null)
        {
            Response.Redirect("Home.aspx");
        }

        sda.deleteper();

        

        RVDepart1.MaximumValue = DateTime.Now.Date.AddMonths(3).ToString("MM/dd/yyyy");
        RVDepart1.MinimumValue = DateTime.Now.Date.ToString("MM/dd/yyyy");

    }
    private void DateFormat()
    {
        foreach (GridViewRow row in gridSearchDetails.Rows)
        {
            Label lbl = new Label();
            lbl =(Label) row.FindControl("Label1");
            lbl.Text = Convert.ToDateTime(lbl.Text).ToString("MMM-dd-yyyy");
            Session["dept_date"] = lbl.Text;
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        
      
        Session["Number_of_passenger"] = ddlNumberOfSeat.SelectedValue;
        search_temp_master after = new search_temp_master();
      
        int noOfSeats = Convert.ToInt32(Session["Number_of_passenger"]);
        if (sbll.insertsearch_temp_master(noOfSeats, txtDepart.Text, ddlFrom.Text, ddlTo.Text, after))
        {

            gridSearchDetails.Visible = true;
            gridSearchDetails.DataBind();
        }
        else
        {
            gridSearchDetails.Visible = true;
            gridSearchDetails.DataBind();
        }
        DateFormat();
    }
    protected void gridSearchDetails_SelectedIndexChanged1(object sender, EventArgs e)
    {
        
        Session["flightid"] = gridSearchDetails.SelectedRow.Cells[0].Text;
        Session["AirLine_Name"] = gridSearchDetails.SelectedRow.Cells[1].Text;
        Session["from_location"] = gridSearchDetails.SelectedRow.Cells[2].Text;
        Session["Departure_Time"] = gridSearchDetails.SelectedRow.Cells[6].Text;
        Session["To_location"] = gridSearchDetails.SelectedRow.Cells[3].Text;
        Session["Arrival_Time"] = gridSearchDetails.SelectedRow.Cells[5].Text;
        Session["Total_fare"] = gridSearchDetails.SelectedRow.Cells[7].Text;
        Session["departure_date"] = Session["dept_date"];
       
        Response.Redirect("Booking.aspx");
    }
}