﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAL;
using BLL;
using DEL;
public partial class Invoice : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userid"] == null)
        {
            Response.Redirect("Home.aspx");
        }

        if (!Page.IsPostBack)
        {
            booking_master bm = new booking_master();
            booking_masterBLL bmbll=new booking_masterBLL();
           
            booking_master bm1 = bmbll.selectBooking(bmbll.booking_id());
            lblAirLineName.Text = bm1.airline_name;
            lblbookingid.Text = bm1.booking_id.ToString();
            Session["Booking_id"] = lblbookingid.Text;
            lblcustomername.Text = bm1.customer_name;
            lblDate.Text = bm1.booking_date.ToString();
            lblDateOfJourney.Text = bm1.date_of_journey.ToString();
            lblDepartureTime.Text=Session["Departure_Time"].ToString();
            lblGoingTo.Text = bm1.to_location;
            lblLeavingFrom.Text = bm1.from_location;
            lblNoOfPassengers.Text = bm1.no_of_seats.ToString();
            lblTotalPrice.Text = bm1.total_price.ToString();
            Session["flight_id"] = bm1.flight_id;
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        booking_masterBLL bmbll = new booking_masterBLL();
        if (bmbll.deletebooking_master(Session["Booking_id"]))
        {
            Label1.Text = "Booking Cancelled";
        }
       

        int totalSeats = bmbll.SelectTotalSeats(Session["flight_id"].ToString());
        int updatedSeats = totalSeats + Convert.ToInt32(lblNoOfPassengers.Text);
        bmbll.UpdateTotalNoOfSeats(Session["flight_id"].ToString(), updatedSeats);


    }

    protected void btnOk_Click(object sender, EventArgs e)
    {
        Response.Redirect("Search.aspx");
    }

}