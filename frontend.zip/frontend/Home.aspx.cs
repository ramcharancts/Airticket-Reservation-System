﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLL;
using DAL;
using DEL;

public partial class Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {

        Session["userid"] = txtUserName.Text.ToLower();
        Session["password"] = txtPassWord.Text;
     
        if (txtUserName.Text == "Admin" && txtPassWord.Text=="AdminARS")
        {
            Response.Redirect("Admin.aspx");
        }


        user_masterBLL umbll = new user_masterBLL();
        user_master um=umbll.loginvalidation(Session["userid"], Session["password"]);
        if (um != null)
        {
            Session["customer_id"] = um.customer_id;
            Session["customer_name"] = um.customer_name;
        }
        else
        {
            error.Text = "Invalid Login Details";
        }
        if (Session["customer_id"]!=null)
        {
            Response.Redirect("Search.aspx");
        }
        else
        {
            //alertlogin. = "Invalid login details";
            
        }

    }
}