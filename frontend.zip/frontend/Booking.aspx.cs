﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAL;
using DEL;
using BLL;
public partial class Booking : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userid"] == null)
        {
            Response.Redirect("Home.aspx");
        }
        if (!Page.IsPostBack)
        {
            txtCustomerName.Text = Session["customer_name"].ToString();
            txtLeavingFrom.Text = Session["from_location"].ToString();
            txtGoingTo.Text = Session["To_location"].ToString();
            txtDateOfJourney.Text = Session["departure_date"].ToString();
            txtdeparture_time.Text = Session["Departure_Time"].ToString();
            txtAirlineName.Text = Session["AirLine_Name"].ToString();
            txtFlightNo.Text = Session["flightid"].ToString();
            txtNoOfPassengers.Text = Session["Number_of_passenger"].ToString();
            txtTotalFare.Text = Session["Total_fare"].ToString();
            txtBookingDate.Text = DateTime.Now.Date.ToString("MMM-dd-yyyy");
        }

    }
    protected void bookingsubmit_Click(object sender, EventArgs e)
    {
        search_temp_masterDAL sda = new search_temp_masterDAL();
        booking_master bm = new booking_master();
        booking_masterBLL bmbll = new booking_masterBLL();
        bm.flight_id = txtFlightNo.Text;
        bm.from_location = txtLeavingFrom.Text;
        bm.airline_name = txtAirlineName.Text;
        bm.booking_date = txtBookingDate.Text;
        bm.date_of_journey = txtDateOfJourney.Text;
        bm.email_id = txtemailid.Text;
        TimeSpan t = DateTime.Parse(Session["Arrival_Time"].ToString()) - DateTime.Parse(Session["Departure_Time"].ToString());
        bm.customer_name = txtCustomerName.Text;
        bm.duration =t.TotalHours.ToString()+"Hrs";
        bm.total_price = Double.Parse(txtTotalFare.Text);
        bm.address = txtaddress.Text;
        bm.customer_id =double.Parse( Session["customer_id"].ToString());
        bm.no_of_seats = Convert.ToInt32( txtNoOfPassengers.Text);
        
        bm.passenger_name = txtpassengernames.Text;
        bm.phone = txtphone.Text;
        bm.to_location = txtGoingTo.Text;

        bmbll.insertbooking_master(bm);
        

        int totalSeats = bmbll.SelectTotalSeats(txtFlightNo.Text);

        int updatedSeats = totalSeats - Convert.ToInt32(txtNoOfPassengers.Text);
        bmbll.UpdateTotalNoOfSeats(txtFlightNo.Text, updatedSeats);

        sda.deleteper();
        Response.Redirect("Invoice.aspx");
    }

    
}
    



