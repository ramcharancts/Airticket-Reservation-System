﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLL;
using DEL;

public partial class Admin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnAdmin_Click(object sender, EventArgs e)
    {
        flight_master fm = new flight_master();
        
        fm.arrival_date = DateTime.ParseExact(txtArrivalDate.Text, "yyyy-MM-dd", null);
        fm.arrival_time = DateTime.ParseExact(txtarraivaltime.Text, "HH:mm", null);
        fm.departure_date = DateTime.ParseExact(txtDepartureDate.Text, "yyyy-MM-dd", null);
        fm.departure_time = DateTime.ParseExact(txtdeparturetime .Text, "HH:mm", null);
        fm.fare = double.Parse(txtFare.Text);
        fm.flight_id = txtFlightID.Text;
        fm.total_seats = int.Parse(txttotalseats.Text);
        flight_masterBLL fmbll = new flight_masterBLL();
        
      

        airline_master am = new airline_master();
        am.flight_id = txtFlightID.Text;
        am.airline_name = txtAirlineName.Text;
        am.airline_id = txtAirlineID.Text;
        airline_masterBLL ambll = new airline_masterBLL();
       
       

        location_master lm = new location_master();
        lm.flight_id = txtFlightID.Text;
        lm.from_location = ddlFrom.SelectedValue;
        lm.to_location = ddlTo.SelectedValue;
        lm.location_id = txtLocationId.Text;
        location_masterBLL lmbll = new location_masterBLL();
        
        if (fmbll.insertflight_master(fm) &&  ambll.insertairline_master(am) && lmbll.insertlocation_master(lm))
        {
            Label1.Text = "SUCCESS";
        }
    }
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }
}