-- ================================================
-- Template generated from Template Explorer using:
-- Create Procedure (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the procedure.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		vikash 
-- Create date: 3-9-19
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE deleteflightmaster 
	-- Add the parameters for the stored procedure here
	@flight_id nvarchar(50),
	@departure_time datetime,
	@arrival_time datetime,
	@fare numeric(18,2),
	@total_seats int,
	@departure_date date,
	@arrival_date date
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	delete from flight_master
	where flight_id=@flight_id;
END
GO
