-- ================================================
-- Template generated from Template Explorer using:
-- Create Procedure (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the procedure.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Abdul
-- Create date: 3/9/19
-- Description:	ARS_schema_User_Master
-- =============================================
CREATE PROCEDURE updateusermaster 
	-- Add the parameters for the stored procedure here
	@customer_id numeric(18,0),
	@customer_name nvarchar(50),
	@date_of_birth date,
	@email_id nvarchar(50),
	@password nvarchar(15),
	@phone_number nvarchar(10),
	@address nvarchar(100),
	@gender nvarchar(10),
	@booking_id numeric(18,0)

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	update user_master 
	set customer_name=@customer_name,date_of_birth=@date_of_birth,email_id=@email_id,password=@password,phone_number=@phone_number,address=@address,gender=@gender
	where customer_id=@customer_id;
	
END
GO