-- ================================================
-- Template generated from Template Explorer using:
-- Create Procedure (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the procedure.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		jhahnavi
-- Create date: 3/9/19
-- Description:	SSN_master
-- =============================================
CREATE PROCEDURE updatessnmaster 
	-- Add the parameters for the stored procedure here
	@ssn_type nvarchar(50),
	@ssn_number nvarchar(50),
	@customer_id numeric(18,0)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	update ssn_master
	set ssn_type=@ssn_type,ssn_number=@ssn_number
	where customer_id=@customer_id;
END
GO
