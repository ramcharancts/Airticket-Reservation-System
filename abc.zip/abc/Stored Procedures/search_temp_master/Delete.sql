-- ================================================
-- Template generated from Template Explorer using:
-- Create Procedure (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the procedure.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		shruti
-- Create date: 3/9/19
-- Description:	search_temp_master
-- =============================================
CREATE PROCEDURE deletesearch_temp_master
	-- Add the parameters for the stored procedure here
	@search_id numeric(18,0),
	@airline_name nvarchar(50),
	@from_location nvarchar(50),
	@departure_date datetime,
	@to_location nvarchar(50),
	@arrival_date datetime,
	@fare numeric(18,0)
	
	
	
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	 delete from  search_temp_master 
	 where search_id=@search_id
	 
END
GO