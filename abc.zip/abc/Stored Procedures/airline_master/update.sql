-- ================================================
-- Template generated from Template Explorer using:
-- Create Procedure (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the procedure.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		shruti
-- Create date: 3/9/19
-- Description:	airline_master
-- =============================================
CREATE PROCEDURE updateairlinemaster 
	-- Add the parameters for the stored procedure here
	@airline_id nvarchar(50),
	@airline_name nvarchar(50),
	@flight_id nvarchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	update airline_master
	set airline_id=@airline_id,airline_name=@airline_name
	where flight_id=@flight_id

	
END
GO