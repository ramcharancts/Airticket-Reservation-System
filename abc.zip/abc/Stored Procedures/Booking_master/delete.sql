-- ================================================
-- Template generated from Template Explorer using:
-- Create Procedure (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the procedure.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		vikash
-- Create date: 3-15-2019
-- Description:	Booking table
-- =============================================
CREATE PROCEDURE deletebookingmaster
	-- Add the parameters for the stored procedure here
	@booking_id numeric(18,0),
	@passenger_name nvarchar(50),
	@airline_name nvarchar(50),
	@from_location nvarchar(50),
	@to_location nvarchar(50),
	@no_of_seats int,
	@date_of_journey date,
	@duration time(7),
	@booking_date date,
	@fare numeric(18,2)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	delete from booking_master 
	where booking_id=@booking_id
END
GO