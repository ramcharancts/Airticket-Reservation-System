﻿using System;


namespace DEL 
{
    public class search_temp_master
    {
        public double search_id { get; set; }
        public string flight_id { get; set; }
        public string airline_name { get; set; }
        public string from_location { get; set; }
        public string departure_date { get; set; }
        public string to_location { get; set; }
        public string arrival_date { get; set; }
        public double fare { get; set; }
        public double total_fare { get; set; }
        public int total_seats { get; set; }
        public DateTime departure_time { get; set; }
        public DateTime arrival_time { get; set; }
    }
}
