﻿using System;


namespace DEL
{
    public class location_master
    {
        public string location_id { get; set; }
        public string from_location { get; set; }
        public string to_location { get; set; }
        public string flight_id { get; set; }
    }
}
