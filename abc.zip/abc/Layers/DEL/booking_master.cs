﻿using System;


namespace DEL
{
    public class booking_master
    {
        public double booking_id { get; set; }
        public string passenger_name { get; set; }
        public string airline_name { get; set; }
        public string from_location { get; set; }
        public string to_location { get; set; }
        public int no_of_seats { get; set; }
        public string date_of_journey { get; set; }
        public string duration { get; set; }
        public string booking_date { get; set; }
        public double total_price { get; set; }
        public string flight_id { get; set; }
        public double fare { get; set; }
        public string airline_id { get; set; }
        public double search_id { get; set; }
        public double customer_id { get; set; }
        public string customer_name { get; set; }
        public string email_id { get; set; }
        public string phone { get; set; }
        public string address { get; set; }

    }

	
}
