﻿using System;


namespace DEL
{
    public class user_master
    {
        public double customer_id { get; set; }
        public string customer_name { get; set; }
        public string date_of_birth { get; set; }
        public string email_id { get; set; }
        public string password { get; set; }
        public string phone_number { get; set; }
        public string address { get; set; }
        public string gender { get; set; }
        public string ssn_type { get; set; }
        public string ssn_number { get; set; }
    }
}
