﻿using System;


namespace DEL
{
    public class flight_master
    {
        public string flight_id { get; set; }
        public DateTime departure_time { get; set; }
        public DateTime arrival_time { get; set; }
        public double fare { get; set; }
        public int total_seats { get; set; }
        public DateTime departure_date { get; set; }
        public DateTime arrival_date { get; set; }
        
    }
}
