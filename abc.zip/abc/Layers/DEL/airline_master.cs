﻿using System;


namespace DEL
{
    public class airline_master
    {
        public string airline_id { get; set; }
        public string airline_name { get; set; }
        public string flight_id { get; set; }
    }
}
