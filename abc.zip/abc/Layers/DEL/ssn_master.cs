﻿using System;


namespace DEL
{
    public class ssn_master
    {
        public string ssn_type { get; set; }
        public string ssn_number { get; set; }
        public double customer_id { get; set; }
       
    }
}
