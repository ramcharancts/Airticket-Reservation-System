﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DEL;
using System.Data.SqlClient;
namespace DAL
{
    public class airline_masterDAL : IDAL<airline_master>
    {
        SqlConnection sqlcon = new SqlConnection(DAL.Properties.Settings1.Default.conStr);
        SqlCommand cmd = new SqlCommand();
        //SqlDataReader dr;
        bool IDAL<airline_master>.Save(airline_master entity)
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "insertairlinemaster @airline_id='" + entity.airline_id + "',@airline_name='" + entity.airline_name+"',@flight_id='"+entity.flight_id+"'"; 
                    if (sqlcon.State==System.Data.ConnectionState.Closed)
	                {
		                sqlcon.Open();
	                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                return false;
                
            }
            finally
            {
                sqlcon.Close();
            }
        }
        bool IDAL<airline_master>.Update(airline_master entity)
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "updateairlinemaster @airline_id=" + entity.airline_id + "@airline_name='" + entity.airline_name + "'@flight_id="+entity.flight_id+"";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                return false;

            }
            finally
            {
                sqlcon.Close();
            }
        }
        bool IDAL<airline_master>.Delete(airline_master entity)
        {
            return false;
        }
        airline_master IDAL<airline_master>.GetbyID(object obj)
        {
            return null;
        }
    }
}
