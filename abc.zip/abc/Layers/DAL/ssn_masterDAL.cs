﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DEL;
using System.Data.SqlClient;

namespace DAL
{
    public class ssn_masterDAL : IDAL<ssn_master>
    {
        SqlConnection sqlcon = new SqlConnection(DAL.Properties.Settings1.Default.conStr);
        SqlCommand cmd = new SqlCommand();
        //SqlDataReader dr;
        bool IDAL<ssn_master>.Save(ssn_master ssm)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "insertssnmaster  @ssn_type='"+ssm.ssn_type+"',@ssn_number="+ssm.ssn_number+",@customer_id="+ssm.customer_id+"";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();

                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {

                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }


        bool IDAL<ssn_master>.Update(ssn_master ssm)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "updatessnmaster  @ssn_type='" + ssm.ssn_type + "',@ssn_number=" + ssm.ssn_number + "@customer_id=" + ssm.customer_id + "";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();

                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {

                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }



        bool IDAL<ssn_master>.Delete(ssn_master stm)
        {
            return false;
        }




        ssn_master IDAL<ssn_master>.GetbyID(object obj)
        {
            return null;
        }
    }
}
