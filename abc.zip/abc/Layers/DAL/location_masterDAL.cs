﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DEL;
using System.Data.SqlClient;

namespace DAL
{
    public class location_masterDAL : IDAL<location_master>
    {
        SqlConnection sqlcon = new SqlConnection(DAL.Properties.Settings1.Default.conStr);
        SqlCommand cmd = new SqlCommand();
        //SqlDataReader dr;
        bool IDAL<location_master>.Save(location_master lm)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "insertlocationmaster @location_id='" + lm.location_id + "',@from_location='" + lm.from_location + "',@to_location='" + lm.to_location + "',@flight_id='"+lm.flight_id+"'";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();

                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {

                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }


        bool IDAL<location_master>.Update(location_master lm)
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "updatelocationmaster @location_id=" + lm.location_id + ",@from_location='" + lm.from_location + "',@to_location='" + lm.to_location + "'";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                return false;

            }
            finally
            {
                sqlcon.Close();
            }
        }



        bool IDAL<location_master>.Delete(location_master lm)
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "deletelocationmaster   @location_id=" + lm.location_id + "";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                return false;

            }
            finally
            {
                sqlcon.Close();
            }
        }




        location_master IDAL<location_master>.GetbyID(object obj)
        {
            return null;
        }

    }
}
