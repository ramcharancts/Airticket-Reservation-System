﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DEL;
using System.Data.SqlClient;

namespace DAL
{
    public class user_masterDAL : IDAL<user_master>
    {
        SqlConnection sqlcon = new SqlConnection(DAL.Properties.Settings1.Default.conStr);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;
        bool IDAL<user_master>.Save(user_master um)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "insertusermaster  @customer_name='" + um.customer_name + "',@date_of_birth='" + um.date_of_birth + "',@email_id='" + um.email_id + "',@password='" + um.password + "',@phone_number='" + um.phone_number + "',@address='" + um.address + "',@gender='" + um.gender + "',@ssn_type='" + um.ssn_type + "',@ssn_number=" + um.ssn_number + "";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();

                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {

                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }



        bool IDAL<user_master>.Update(user_master um)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "updateusermaster  @customer_id="+um.customer_id+",@customer_name='" + um.customer_name + "',@date_of_birth='" + um.date_of_birth + "',@email_id='" + um.email_id + "',@phone_number='" + um.phone_number + "',@address='" + um.address + "',@gender='" + um.gender + "',@ssn_type='" + um.ssn_type + "',@ssn_number=" + um.ssn_number + "";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();

                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {

                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }



        bool IDAL<user_master>.Delete(user_master um)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "deleteusermaster  @customer_id=" + um.customer_id + "";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();

                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {

                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }


        public user_master loginvalidation(object obj1, object obj2)
        {
            user_master um = new user_master();
            try
            {
                cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "loginvalidation  @email_id='" + obj1 + "',@password='" + obj2 + "'";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();

                }
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    um.customer_id = Convert.ToInt32(dr["customer_id"]);
                    um.customer_name = dr["customer_name"].ToString();
                    um.date_of_birth = dr["date_of_birth"].ToString();
                    um.email_id = dr["email_id"].ToString();
                    um.phone_number = dr["phone_number"].ToString();
                    um.password = dr["password"].ToString();
                    um.address = dr["address"].ToString();
                    um.gender = dr["gender"].ToString();
                    return um;
                }
                else
                {
                    return null;
                }

            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                sqlcon.Close();
            }
        }




        user_master IDAL<user_master>.GetbyID(object obj)
        {
            user_master um = new user_master();
            try
            {
                cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "selectcustomerid";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();

                }
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    um.customer_id = Convert.ToInt32(dr["customer_id"]);
                    um.customer_name = dr["customer_name"].ToString();
                    um.date_of_birth = dr["date_of_birth"].ToString();
                    um.email_id = dr["email_id"].ToString();
                    um.phone_number = dr["phone_number"].ToString();
                    um.password = dr["password"].ToString();
                    um.address = dr["address"].ToString();
                    um.gender = dr["gender"].ToString();

                }
                return um;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                sqlcon.Close();
            }
        }


        public user_master updateprofile(object obj)
        {
            user_master um = new user_master();
            try
            {
                cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "selectusermaster @customer_id = '" + obj + "'";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();

                }
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    um.customer_id = Convert.ToInt32(dr["customer_id"]);
                    um.customer_name = dr["customer_name"].ToString();
                    um.date_of_birth = dr["date_of_birth"].ToString();
                    um.email_id = dr["email_id"].ToString();
                    um.phone_number = dr["phone_number"].ToString();
                    um.password = dr["password"].ToString();
                    um.address = dr["address"].ToString();
                    um.gender = dr["gender"].ToString();
                    um.ssn_type = dr["ssn_type"].ToString();
                    um.ssn_number = dr["ssn_number"].ToString();

                }
                return um;
            }

            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                sqlcon.Close();
            }
        }

        public bool Email(object obj1)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "emailvalidation @email_id='"+obj1+"'";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();

                }
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch (Exception ex)
            {

                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }

        public bool SSN(object obj1)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "ssnnumbervalidation @ssn_number='"+obj1+"'";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();

                }
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch (Exception ex)
            {

                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }
    }
}
