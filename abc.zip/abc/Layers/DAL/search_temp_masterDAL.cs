﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DEL;
using System.Data.SqlClient;
using System.Data;
namespace DAL
{
    public class search_temp_masterDAL : IDAL<search_temp_master>
    {
        SqlConnection sqlcon = new SqlConnection(DAL.Properties.Settings1.Default.conStr);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;
        DataTable dt = new DataTable();
        SqlDataAdapter da;
       public bool inserttable(int noofSeats, object date,object from,object to,search_temp_master stm)
        {
            
                DataTable dt = searchflight(date, from, to);
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        int total_fare = Convert.ToInt32(row["fare"]) * noofSeats;
                        try
                        {
                            if (Convert.ToInt32(row["total_seats"]) >= noofSeats)
                            {
                                cmd = new SqlCommand();
                                cmd.Connection = sqlcon;
                               
                               
                                cmd.CommandText = "insertsearch_temp_master @flight_id='" + row["flight_id"].ToString() + "', @airline_name='" + row["airline_name"] + "',@from_location='" + row["from_location"] + "',@departure_date='" +row["departure_date"] + "',@to_location='" + row["to_location"] + "',@arrival_date='" + row["arrival_date"] + "',@fare=" + row["fare"] + ",@total_fare=" + total_fare + ",@total_seats=" + row["total_seats"] + ",@departure_time='" + row["departure_time"] + "',@arrival_time='" + row["arrival_time"] + "'";
                                if (sqlcon.State == System.Data.ConnectionState.Closed)
                                {
                                    sqlcon.Open();

                                }
                                cmd.ExecuteNonQuery();

                            }
                        }
                        catch (Exception ex) { }
                    }
                    return true;
                }
                else
                {
                    return false;
                }
           
            

        }

       bool IDAL<search_temp_master>.Save( search_temp_master stm)
       {
           return false;
       }

        bool IDAL<search_temp_master>.Update(search_temp_master stm)
        {
            return false;
        }

        public bool deleteper()
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "deletesearch_temp_master";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                return false;

            }
            finally
            {
                sqlcon.Close();
            }
        }

        bool IDAL<search_temp_master>.Delete(search_temp_master stm)
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "deletesearch_temp_master   @search_id=" + stm.search_id + "";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                return false;

            }
            finally
            {
                sqlcon.Close();
            }
        }




        search_temp_master IDAL<search_temp_master>.GetbyID(object obj)
        {
            return null;
        }

        public DataTable searchflight(object date,object from,object to)
        {
          
            search_temp_master stm = new search_temp_master();
            
            try
            {
                DataSet ds = new DataSet();
                da=new SqlDataAdapter("SearchFlight @departure_date='" +date + "',@from_location='" + from + "',@to_location='" + to + "'",sqlcon);
                da.Fill(ds, "data");
                dt = ds.Tables["data"];
                   
                  

                    return dt;
               

            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                sqlcon.Close();
            }
        }
    }
}
