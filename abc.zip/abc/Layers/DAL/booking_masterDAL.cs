﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DEL;
using System.Data.SqlClient;
namespace DAL
{
    public class booking_masterDAL:IDAL<booking_master>
    {
        SqlConnection sqlcon = new SqlConnection(DAL.Properties.Settings1.Default.conStr);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;
        bool IDAL<booking_master>.Save(booking_master bm)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "insertbookingmaster @passenger_name='" + bm.passenger_name + "',@total_price="+bm.total_price+",@airline_name='" + bm.airline_name + "',@from_location='" + bm.from_location + "',@to_location='" + bm.to_location + "',@no_of_seats=" + bm.no_of_seats + ",@date_of_journey='" + bm.date_of_journey + "',@duration='" + bm.duration + "',@booking_date='" + bm.booking_date + "',@customer_id="+bm.customer_id+",@customer_name='"+bm.customer_name+"',@flight_id='"+bm.flight_id+"',@email_id='"+bm.email_id+"',@phone='"+bm.phone+"',@address='"+bm.address+"'";
                if (sqlcon.State==System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();
                  
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                
                return false;
            }
            finally 
            {
                sqlcon.Close();
            }
        }


        bool IDAL<booking_master>.Update(booking_master bm)
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "updatebookingmaster  @passenger_name='" + bm.passenger_name + "',@airline_name='" + bm.airline_name + "',@from_location='" + bm.from_location + "',@to_location='" + bm.to_location + "',@no_of_seats=" + bm.no_of_seats + ",@date_of_journey='" + bm.date_of_journey + "',@duration='" + bm.duration + "',@booking_date='" + bm.booking_date + "',@fare=" + bm.fare + "";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                return false;

            }
            finally
            {
                sqlcon.Close();
            }
        }



        bool IDAL<booking_master>.Delete(booking_master bm)
        {
            return false;
        }

        public bool deleteBooking(object obj)
        {

            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "deletebookingmaster   @booking_id=" + obj + "";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                return false;

            }
            finally
            {
                sqlcon.Close();
            }
        }


       
        booking_master IDAL<booking_master>.GetbyID(object obj)
        {
            booking_master bm = new booking_master();
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "selectbookingmaster @booking_id=" + obj + "";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    bm.customer_name = dr["customer_name"].ToString();
                    bm.address = dr["address"].ToString();
                    bm.airline_id = dr["airline_id"].ToString();
                    bm.airline_name = dr["airline_name"].ToString();
                    bm.booking_date = dr["booking_date"].ToString();
                    bm.booking_id = double.Parse(dr["booking_id"].ToString());
                    bm.customer_id = double.Parse(dr["customer_id"].ToString());
                    bm.date_of_journey = dr["date_of_journey"].ToString();
                    bm.duration = dr["duration"].ToString();
                    bm.email_id = dr["email_id"].ToString();
                    //bm.fare = double.Parse(dr["fare"].ToString());
                    bm.flight_id = dr["flight_id"].ToString();
                    bm.from_location = dr["from_location"].ToString();
                    bm.no_of_seats = Convert.ToInt32(dr["no_of_seats"].ToString());
                    bm.passenger_name = dr["passenger_name"].ToString();
                    bm.phone = dr["phone"].ToString();
                    //bm.search_id = double.Parse(dr["search_id"].ToString());
                    bm.to_location = dr["to_location"].ToString();
                    bm.total_price = double.Parse(dr["total_price"].ToString());
                    return bm;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                return null;

            }
            finally
            {
                sqlcon.Close();
            }
        }

        public double booking_id()
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "select max(booking_id) as booking_id from booking_master";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                 dr = cmd.ExecuteReader();
                 if (dr.HasRows)
                 {
                     dr.Read();
                     return double.Parse(dr["booking_id"].ToString());
                 }
                 else 
                 {
                     return 0;
                 }
            }
            catch (Exception ex)
            {
                return 0;

            }
            finally
            {
                sqlcon.Close();
            }
        }

        public int SelectTotalSeats(object obj)
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "SelectNoOfSeats @flight_id=" + obj + "";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    return Convert.ToInt32(dr["total_seats"]);
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception ex)
            {
                return 0;

            }
            finally
            {
                sqlcon.Close();
            }
        }

        public bool UpdateTotalNoOfSeats(object obj,object obj1)
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "UpdateNoOfSeats @flight_id=" + obj + ",@total_seats="+obj1+"";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();

                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                return false;

            }
            finally
            {
                sqlcon.Close();
            }
        }


    }
}
