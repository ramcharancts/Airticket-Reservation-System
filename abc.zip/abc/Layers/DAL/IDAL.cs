﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public interface IDAL<TEntity>
    {
        bool Save(TEntity entity);
        bool Delete(TEntity entity);
        bool Update(TEntity entity);
        TEntity GetbyID(object obj);
    }
}
