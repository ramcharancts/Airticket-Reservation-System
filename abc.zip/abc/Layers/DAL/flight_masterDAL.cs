﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DEL;
using System.Data.SqlClient;

namespace DAL
{
    
        public class flight_masterDAL : IDAL<flight_master>
        {
            SqlConnection sqlcon = new SqlConnection(DAL.Properties.Settings1.Default.conStr);
            SqlCommand cmd = new SqlCommand();
            //SqlDataReader dr;
            bool IDAL<flight_master>.Save(flight_master fm)
            {
                try
                {
                    cmd = new SqlCommand();
                    cmd.Connection = sqlcon;
                    cmd.CommandText = "insertflightmaster @flight_id="+fm.flight_id+",@departure_time='"+fm.departure_time+"',@arrival_time='"+fm.arrival_time+"',@fare="+fm.fare+",@total_seats="+fm.total_seats+",@departure_date='"+fm.departure_date+"',@arrival_date='"+fm.arrival_date+"'";
                    if (sqlcon.State == System.Data.ConnectionState.Closed)
                    {
                        sqlcon.Open();

                    }
                    cmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {

                    return false;
                }
                finally
                {
                    sqlcon.Close();
                }
            }


            bool IDAL<flight_master>.Update(flight_master fm)
            {
                try
                {
                    cmd.Connection = sqlcon;
                    cmd.CommandText = "updateflightmaster @flight_id=" + fm.flight_id + ",@departure_time='" + fm.departure_time + "',@arrival_time='" + fm.arrival_time + "',@fare=" + fm.fare + ",@total_seats=" + fm.total_seats + ",@departure_date='" + fm.departure_date + "',@arrival_date='" + fm.arrival_date + "'";
                    if (sqlcon.State == System.Data.ConnectionState.Closed)
                    {
                        sqlcon.Open();
                    }
                    cmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    return false;

                }
                finally
                {
                    sqlcon.Close();
                }
            }



            bool IDAL<flight_master>.Delete(flight_master fm)
            {
                try
                {
                    cmd.Connection = sqlcon;
                    cmd.CommandText = "deleteflightmaster   @flight_id=" +  fm.flight_id +"";
                    if (sqlcon.State == System.Data.ConnectionState.Closed)
                    {
                        sqlcon.Open();
                    }
                    cmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    return false;

                }
                finally
                {
                    sqlcon.Close();
                }
            }




            flight_master IDAL<flight_master>.GetbyID(object obj)
            {
                return null;
            }

        }
    
}
