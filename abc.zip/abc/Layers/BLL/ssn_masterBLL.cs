﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using DEL;
namespace BLL
{
    public class ssn_masterBLL
    {
        ssn_master ssm = new ssn_master();
        IDAL<ssn_master> ssmDAL = new ssn_masterDAL();
        public bool insertssnmaster(ssn_master ssm)
        {
            return ssmDAL.Save(ssm);
        }

        public bool updatessnmaster(ssn_master ssm)
        {
            return ssmDAL.Update(ssm);
        }

    }
}
