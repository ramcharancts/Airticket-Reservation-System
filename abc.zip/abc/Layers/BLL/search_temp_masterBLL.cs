﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using DEL;
using System.Data;
namespace BLL
{
    public class search_temp_masterBLL
    {
        search_temp_masterDAL stdal = new search_temp_masterDAL();
        search_temp_master stm = new search_temp_master();
        IDAL<search_temp_master> stmDAL = new search_temp_masterDAL();
        public bool insertsearch_temp_master(int noofseat,object date,object from,object to, search_temp_master stm)
        {
            return stdal.inserttable(noofseat,date, from, to, stm);
        }
       
        public bool deletesearch_temp_master(search_temp_master stm)
        {
            return stmDAL.Delete(stm);
        }
        public DataTable searchtemp(object date, object from, object to)
        {
            return stdal.searchflight(date,from,to);
            
        }
    }
}
