﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using DEL;
namespace BLL
{
    public class airline_masterBLL
    {
        airline_master am = new airline_master();
        IDAL<airline_master> amDAL = new airline_masterDAL();
        public bool insertairline_master(airline_master am)
        {
            return amDAL.Save(am);
        }
        public bool updateairline_master(airline_master am)
        {
            return amDAL.Update(am);
        }
    }
}
