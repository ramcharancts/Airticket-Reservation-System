﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using DEL;

namespace BLL
{
    public class user_masterBLL
    {
        user_master um = new user_master();
        IDAL<user_master> umDAL = new user_masterDAL();
        user_masterDAL udal = new user_masterDAL();
        public bool insertusermaster(user_master um)
        {
            return umDAL.Save(um);
        }

        public bool updateusermaster(user_master um)
        {
            return umDAL.Update(um);
        }
        public bool deleteusermaster(user_master um)
        {
            return umDAL.Delete(um);
        }
        public user_master getID(user_master um)
        {
            return umDAL.GetbyID(um);
        }
        public user_master loginvalidation(object obj1, object obj2)
        {
          user_master cid = udal.loginvalidation(obj1, obj2);
            if (cid!=null)
            {
                return cid;
            }
            else
            {
                return null;
            }
        }
        public user_master updateprofile(object obj)
        {
            return udal.updateprofile(obj);

        }

        public bool email(object obj)
        {
            return udal.Email(obj);
        }
        public bool SSN(object obj)
        {
            return udal.SSN(obj);
        }
    }

}
