﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using DEL;

namespace BLL
{
    public class location_masterBLL
    {
        location_master lm = new location_master();
        IDAL<location_master> lmDAL = new location_masterDAL();
        public bool insertlocation_master(location_master lm)
        {
            return lmDAL.Save(lm);
        }
        public bool updatelocation_master(location_master lm)
        {
            return lmDAL.Update(lm);
        }
        public bool deletelocation_master(location_master lm)
        {
            return lmDAL.Delete(lm);
        }

    }
}
