﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using DEL;

namespace BLL
{
    public class loginBLL
    {
        user_master u = new user_master();
        loginDAL ldal = new loginDAL();
        public bool LoginValidation(object obj1,object obj2)
        {
            
            return true;
        }

    }
}
