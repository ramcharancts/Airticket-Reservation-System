﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using DEL;

namespace BLL
{

    public class flight_masterBLL
    {
        flight_master fm = new flight_master();
        IDAL<flight_master> fmDAL = new flight_masterDAL();
        public bool insertflight_master(flight_master fm)
        {
            return fmDAL.Save(fm);
        }
        public bool updateflight_master(flight_master fm)
        {
            return fmDAL.Update(fm);
        }
        public bool deleteflight_master(flight_master fm)
        {
            return fmDAL.Delete(fm);
        }

    }

}
