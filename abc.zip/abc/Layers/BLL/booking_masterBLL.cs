﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using DEL;

namespace BLL
{
   
        public class booking_masterBLL
        {
            booking_master bm = new booking_master();
            IDAL<booking_master> bmDAL = new booking_masterDAL();
            booking_masterDAL bmdal = new booking_masterDAL();
            public bool insertbooking_master(booking_master bm)
            {
                return bmDAL.Save(bm);
            }
            public bool updatebooking_master(booking_master bm)
            {
                return bmDAL.Update(bm);
            }
            public bool deletebooking_master(object obj)
            {
                return bmdal.deleteBooking(obj);
            }
           
            public booking_master selectBooking(object obj)
            {
                return bmDAL.GetbyID(obj);
            }
            public double booking_id()
            {
                return bmdal.booking_id();
            }

            public int SelectTotalSeats(object obj)
            {
                return bmdal.SelectTotalSeats(obj);
            }

            public bool UpdateTotalNoOfSeats(object obj,object obj1)
            {
                return bmdal.UpdateTotalNoOfSeats(obj,obj1);
            }

       }
    
}
