﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLL;
using DAL;
using DEL;
public partial class Search : System.Web.UI.Page
{
    search_temp_masterDAL sda = new search_temp_masterDAL();
    search_temp_masterBLL sbll = new search_temp_masterBLL();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userid"] == null)
        {
            Response.Redirect("Home.aspx");
        }
      
        sda.deleteper();
    }
    //protected void btnSubmit_Click(object sender, EventArgs e)
    //{
    //    //Response.Redirect("SearchGrid.aspx");
      
    //    search_temp_master after = new search_temp_master();
    //    search_temp_master stmp= sbll.searchtemp(txtDepart.Text, txtFrom.Text, txtTo.Text);
    //    after.total_fare =double.Parse( ddlNumberOfSeat.SelectedValue) * stmp.fare;
    //    after.flight_id = stmp.flight_id;
    //    after.airline_name = stmp.airline_name;

    //    string[] ad = stmp.arrival_date.Split(' ');
    //    after.arrival_date = ad[0];
    //    //after.arrival_date = stmp.arrival_date;
    //    //after.departure_date = stmp.departure_date;

    //    string[] dd = stmp.departure_date.Split(' ');
    //    after.departure_date = dd[0];

    //    after.fare = stmp.fare;
    //    after.from_location = stmp.from_location;
    //    after.search_id = stmp.search_id;
    //    after.total_seats = stmp.total_seats;
    //    after.to_location = stmp.to_location;

    //    if (sbll.insertsearch_temp_master(after))
    //    {
    //        gridSearchDetails.Visible = true;
    //    }
        

       
   // }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        Session["Number_of_passenger"] = ddlNumberOfSeat.SelectedValue;
        search_temp_master after = new search_temp_master();
        //DataTable stmp = sbll.searchtemp(txtDepart.Text, ddlFrom.Text, ddlTo.Text);
        //if (stmp != null)
        //{
        //    after.total_fare = double.Parse(ddlNumberofSeats.SelectedValue) * stmp.fare;
        //    after.flight_id = stmp.flight_id;
        //    after.airline_name = stmp.airline_name;

        //    string[] ad = stmp.arrival_date.Split(' ');
        //    after.arrival_date = ad[0];
        //    //after.arrival_date = stmp.arrival_date;
        //    //after.departure_date = stmp.departure_date;

        //    string[] dd = stmp.departure_date.Split(' ');
        //    after.departure_date = dd[0];

        //    after.fare = stmp.fare;
        //    after.from_location = stmp.from_location;
        //    after.search_id = stmp.search_id;
        //    after.total_seats = stmp.total_seats;
        //    after.to_location = stmp.to_location;
        int noOfSeats = Convert.ToInt32(Session["Number_of_passenger"]);
        if (sbll.insertsearch_temp_master(noOfSeats, txtDepart.Text, ddlFrom.Text, ddlTo.Text, after))
        {
            gridSearchDetails.Visible = true;

        }
        else
        {
            gridSearchDetails.Visible = true;
        }
        //}
        //else {
        //    gridSearchDetails.Visible = true;
        //}
    }
    protected void gridSearchDetails_SelectedIndexChanged1(object sender, EventArgs e)
    {
        Session["flightid"] = gridSearchDetails.SelectedRow.Cells[0].Text;
        Session["AirLine_Name"] = gridSearchDetails.SelectedRow.Cells[1].Text;
        Session["from_location"] = gridSearchDetails.SelectedRow.Cells[2].Text;
        Session["Departure_Time"] = gridSearchDetails.SelectedRow.Cells[6].Text;
        Session["To_location"] = gridSearchDetails.SelectedRow.Cells[3].Text;
        Session["Arrival_Time"] = gridSearchDetails.SelectedRow.Cells[7].Text;
        Session["Total_fare"] = gridSearchDetails.SelectedRow.Cells[5].Text;
        Session["departure_date"] = gridSearchDetails.SelectedRow.Cells[4].Text;
        Response.Redirect("Booking.aspx");
    }
}