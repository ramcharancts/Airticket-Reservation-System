﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLL;
using DAL;
using DEL;

public partial class UserProfile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        rvdob.MaximumValue = DateTime.Now.Date.ToString("MM/dd/yyyy");
        rvdob.MinimumValue = DateTime.Now.Date.AddYears(-130).ToString("MM/dd/yyyy");

        if (Session["userid"] == null)
        {
            Response.Redirect("Home.aspx");
        }
     
       

        if (!Page.IsPostBack)
        {
            user_masterBLL updatebll = new user_masterBLL();
            user_master update = updatebll.updateprofile(Session["customer_id"]);
            if (update != null)
            {
                txtCustomerid.Text = update.customer_id.ToString();
                txtName.Text = update.customer_name;
                txtAddress.Text = update.address;
                txtDateOfBirth.Text = update.date_of_birth.ToString();
                txtEmail.Text = update.email_id;
                txtPhone.Text = update.phone_number;
                txtSSNNumber.Text = update.ssn_number;
                ddlSSNType.SelectedValue = update.ssn_type;
                switch (update.gender)
                {
                    case "Male":
                        rbMale.Checked = true;
                        break;
                    case "Female":
                        rbFemale.Checked = true;
                        break;
                    case "Other":
                       rbOthers.Checked = true;
                        break;
                    default:
                        break;
                }

            }
        }
    }

    protected void ddlSSNType_SelectedIndexChanged(object sender, EventArgs e)
    {
        switch (ddlSSNType.SelectedItem.Text)
        {
            case "Aadhar": revssnnumber.ValidationExpression = "([0-9]{12})";
                           revssnnumber.ErrorMessage = "Enter Valid Number";
                            txtSSNNumber.MaxLength = 12;
                break;
            case "Driving Licence": revssnnumber.ValidationExpression = "(^[A-Z]{2}[0-9]{14}$)";
                                    revssnnumber.ErrorMessage = "Enter Valid Number";
                                    txtSSNNumber.MaxLength = 15;
                break;

            case "PAN": revssnnumber.ValidationExpression = "([A-Z]{5}[0-9]{4}[A-Z]{1})";
                revssnnumber.ErrorMessage = "Enter Valid Number";
                txtSSNNumber.MaxLength = 10;
                break;
        }
    }
    protected void txtSSNNumber_TextChanged(object sender, EventArgs e)
    {

    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        user_master um = new user_master();
        um.customer_id = double.Parse(txtCustomerid.Text);
        um.customer_name = txtName.Text;
        um.address = txtAddress.Text;
        um.date_of_birth = txtDateOfBirth.Text;
        um.email_id = txtEmail.Text;
        if (rbMale.Checked)
        {
            um.gender = "Male";
        }
        else if (rbFemale.Checked)
        {
            um.gender = "Female";
        }
        else
        {
            um.gender = "Other";
        }
        um.phone_number = txtPhone.Text;
        um.ssn_number = txtSSNNumber.Text;
        um.ssn_type = ddlSSNType.SelectedValue;
        user_masterBLL umbll = new user_masterBLL();
        if (umbll.updateusermaster(um))
        {
            lblupdateprofile.Text = "SUCCESS";
        }
        else
        {
            lblupdateprofile.Text = "Not Updated";
        }
    }
}