﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DEL;
using DAL;
using BLL;
public partial class RoundTripSearch : System.Web.UI.Page
{
    search_temp_masterBLL sbll = new search_temp_masterBLL();
    protected void Page_Load(object sender, EventArgs e)
    {
        
        search_temp_masterDAL sda = new search_temp_masterDAL();
        sda.deleteper();
    }
}